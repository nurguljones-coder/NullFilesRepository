/* Null Shell: shared data (loaded by both the page script and the popup). */
var NS = (() => {
  const BONUS = ['Take 5 more minutes ({s}s)', 'Take 5 more minutes (once)', 'No extra time left today'];
  const MOON = 'radial-gradient(circle closest-side at 50% 54%, #f4e7c4 0 90%, transparent 92%)';

  // Internal ids (paper, midnight, ...) are kept so saved settings survive renames.
  const PRESETS = {
    paper: {
      label: 'ArtHouse',
      pal: { bg: '#f4eedf', fg: '#141414', accent: '#d8342b', acid: '#f2c12e', blood: '#1f4fa3' },
      pill: '',
      mascot: { f: 'mouth.png', ar: '348 / 202', w: 'clamp(210px,16vw,300px)', peek: '30%' },
      lock: { title: 'ENOUGH.', text: 'You used your {m} minutes. Put the phone down and make something raw.',
              tick: 'SAMO\u00A9 AS AN END TO MINDLESS SCROLLING',
              bonus: ['Five more ({s}s)', 'Five more (once)', 'No more. Go make something.'] },
    },
    midnight: {
      label: 'Nocturne',
      pal: { bg: '#0f1217', fg: '#e8dfcc', accent: '#f0a84b', acid: '#7fb7b0', blood: '#b8452d' },
      pill: '\u2668 ',
      mascot: { f: 'monkey.png', ar: '420 / 345', w: 'clamp(190px,14vw,260px)', peek: '24%', plate: MOON },
      lock: { title: 'Time to rest.', text: 'You used your {m} minutes. Let the steam rise. Put the phone down and listen to the water.',
              tick: '\u2668  the lamps are lit  \u2668',
              bonus: ['Five more minutes in the water ({s}s)', 'Five more minutes in the water (once)', 'The bath has gone cold'] },
    },
    terminal: {
      label: 'Cyber',
      pal: { bg: '#0b0f0b', fg: '#9be59b', accent: '#e6f76a', acid: '#4dff6a', blood: '#1c5a1c' },
      pill: '',
      mascot: { f: 'skull.png', ar: '380 / 422', w: 'clamp(170px,12vw,240px)', peek: '30%' },
      lock: { title: 'SESSION TERMINATED', text: '{m} minutes consumed. Jack out.', tick: '// NO CARRIER //',
              bonus: ['Extend session +5 min ({s}s)', 'Extend session +5 min (once)', 'NO EXTENSIONS LEFT'] },
    },
    nullfiles: {
      label: 'Subspace',
      pal: { bg: '#0d0906', fg: '#e3d9bd', accent: '#f29bb3', acid: '#c9cb3c', blood: '#a3271a' },
      pill: 'COLLAPSE T-',
      mascot: { f: 'goblin.png', ar: '420 / 489', w: 'clamp(190px,14vw,270px)', peek: '32%' },
      lockArt: { f: 'forest.jpg', ar: '742 / 960' },
      lock: { title: 'the feed can eat itself.', text: 'Your {m} minutes are gone. Let the timeline rot without you. Go make something ugly.',
              tick: 'FASTER // CLOSE THE TAB // FASTER',
              bonus: ['FEED ME 5 MORE ({s}s)', 'FEED ME 5 MORE (ONCE)', 'NOTHING LEFT. GOOD.'] },
    },
    chud: {
      label: 'Chud',
      pal: { bg: '#ffffee', fg: '#800000', accent: '#117743', acid: '#789922', blood: '#af0a0f' },
      pill: 'Got Sproke? ',
      mascot: { f: 'girl.gif', ar: '1 / 1', w: 'clamp(150px,11vw,210px)', peek: '22%' },
      lock: { title: 'Thread archived.', text: 'You used your {m} minutes. This thread is closed and you cannot reply anymore.',
              tick: 'GOT SPROKE?',
              bonus: ['Bump thread +5 min ({s}s)', 'Bump thread +5 min (once)', 'Thread is dead'] },
    },
    unc: {
      label: 'Unc',
      pal: { bg: '#dfeafa', fg: '#000033', accent: '#003399', acid: '#ff9933', blood: '#6699cc' },
      pill: 'Old Age is Coming: ',
      mascot: { f: 'rollins.png', ar: '398 / 460', w: 'clamp(170px,12vw,240px)', peek: '28%' },
      lock: { title: 'Old age is coming.', text: 'You used your {m} minutes. Call somebody. Go for a walk. Stretch.',
              tick: '~ your Top 8 have logged off ~',
              bonus: ['Five more minutes, kid ({s}s)', 'Five more minutes, kid (once)', 'Go outside'] },
    },
  };

  const ORDER = ['paper', 'terminal', 'chud', 'midnight', 'nullfiles', 'unc'];
  const PLAIN_LOCK = { title: "That's enough for today.", text: 'You used your {m} minutes. The feed will still be here tomorrow.', tick: '', bonus: BONUS };

  const SITE_HOSTS = {
    substack: /(^|\.)substack\.com$/,
    facebook: /(^|\.)facebook\.com$/,
    instagram: /(^|\.)instagram\.com$/,
    tiktok: /(^|\.)tiktok\.com$/,
    youtube: /(^|\.)youtube\.com$/,
    reddit: /(^|\.)reddit\.com$/,
    discord: /(^|\.)discord\.com$/,
  };
  const SITE_LABELS = {
    x: 'X / Twitter', substack: 'Substack', facebook: 'Facebook', instagram: 'Instagram', tiktok: 'TikTok',
    youtube: 'YouTube', reddit: 'Reddit', discord: 'Discord',
  };
  // Skin is on for X and Substack; the other sites run the timer only until their skin is checked on real pages.
  const SITE_DEFAULTS = {
    x: { skin: true, timer: true }, substack: { skin: true, timer: true },
    facebook: { skin: false, timer: true }, instagram: { skin: false, timer: true }, tiktok: { skin: false, timer: true },
    youtube: { skin: false, timer: true }, reddit: { skin: false, timer: true }, discord: { skin: false, timer: true },
  };

  const DEFAULTS = { limitMin: 20, theme: 'paper', mascot: true, blockVideo: false, timerMini: false };

  function normCustom(c) {
    c = c || {};
    const base = PRESETS[c.base] ? c.base : 'nullfiles';
    let colors = c.colors && typeof c.colors === 'object' ? { ...c.colors } : {};
    // older versions stored accent/acid/blood/bg directly on custom
    if (!c.colors) ['accent', 'acid', 'blood', 'bg'].forEach(k => { if (c[k]) colors[k] = c[k]; });
    return { name: (c.name || 'Custom'), base, colors, pill: c.pill || '' };
  }

  function mergeSettings(raw) {
    raw = raw || {};
    const s = { ...DEFAULTS, ...raw };
    if (raw.goblin === false && raw.mascot === undefined) s.mascot = false;
    if (s.theme !== 'custom' && !PRESETS[s.theme]) s.theme = 'paper';
    s.custom = normCustom(raw.custom);
    s.sites = {};
    Object.keys(SITE_DEFAULTS).forEach(k => { s.sites[k] = { ...SITE_DEFAULTS[k], ...((raw.sites || {})[k] || {}) }; });
    return s;
  }

  return { PRESETS, ORDER, PLAIN_LOCK, SITE_HOSTS, SITE_LABELS, SITE_DEFAULTS, DEFAULTS, normCustom, mergeSettings };
})();
