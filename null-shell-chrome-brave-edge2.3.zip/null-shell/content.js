/* Null Shell: page script (Chrome, Brave, Edge, Firefox) */
(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const root = document.documentElement;
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const SITE = Object.keys(NS.SITE_HOSTS).find(k => NS.SITE_HOSTS[k].test(location.hostname)) || 'x';
  root.setAttribute('data-ts-site', SITE);
  const url = (p) => api.runtime.getURL(p);

  // Fonts for the Subspace theme
  const ff = document.createElement('style');
  ff.textContent = `
    @font-face{font-family:'TS Black';src:url("${url('assets/blackletter.woff2')}") format('woff2');}
    @font-face{font-family:'TS Term';src:url("${url('assets/term.woff2')}") format('woff2');}
    @font-face{font-family:'TS Type';src:url("${url('assets/type.woff2')}") format('woff2');}
    @font-face{font-family:'TS Marker';src:url("${url('assets/marker.woff2')}") format('woff2');}
    @font-face{font-family:'TS Hand';src:url("${url('assets/hand.woff2')}") format('woff2');}
    @font-face{font-family:'TS Mincho';src:url("${url('assets/mincho.woff2')}") format('woff2');}
    @font-face{font-family:'TS MinchoB';src:url("${url('assets/minchob.woff2')}") format('woff2');}`;
  root.appendChild(ff);

  const BONUS_SEC = 300;
  const todayKey = () => new Date().toLocaleDateString('en-CA');
  const freshUsage = () => ({ day: todayKey(), seconds: 0, bonus: 0, bonusUsed: false });

  let settings = NS.mergeSettings(null);
  let customImage = null, customImageAr = null;
  let usage = freshUsage();
  let pill = null, mini = null, lock = null, lockTimer = null, appliedSig = null;

  const cfg = () => settings.sites[SITE];
  const isCustom = () => settings.theme === 'custom';
  const baseId = () => (isCustom() ? settings.custom.base : settings.theme);
  const preset = () => NS.PRESETS[baseId()];
  const budget = () => settings.limitMin * 60 + usage.bonus;
  const remaining = () => budget() - usage.seconds;
  const fmt = (s) => { s = Math.max(0, Math.round(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  /* ---------------- colours ---------------- */
  const rgb = (h) => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const mix = (a, b, t) => '#' + a.map((v, i) => Math.round(v * (1 - t) + b[i] * t).toString(16).padStart(2, '0')).join('');
  const lumOf = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;

  const COLOR_PROPS = ['--ts-bg', '--ts-fg', '--ts-mute', '--ts-line', '--ts-accent', '--ts-acid', '--ts-blood', '--ts-scan', '--ts-on-accent'];
  const ART_PROPS = ['--ts-mascot', '--ts-m-w', '--ts-m-ar', '--ts-m-peek', '--ts-m-plate', '--ts-art', '--ts-art-ar', '--ts-art-plate', '--ts-snail'];
  const setVars = (m) => Object.entries(m).forEach(([k, v]) => root.style.setProperty(k, v));
  const flag = (name, on) => (on ? root.setAttribute(name, '') : root.removeAttribute(name));

  function customColors() {
    const p = { ...preset().pal, ...(settings.custom.colors || {}) };
    const bg = rgb(p.bg), fg = rgb(p.fg), acc = rgb(p.accent);
    return {
      '--ts-bg': p.bg, '--ts-fg': p.fg, '--ts-mute': mix(bg, fg, 0.55), '--ts-line': mix(bg, fg, 0.16),
      '--ts-accent': p.accent, '--ts-acid': p.acid, '--ts-blood': p.blood,
      '--ts-rule': mix(bg, fg, 0.6), '--ts-icon-filter': lumOf(bg) > 0.55 ? 'brightness(.42) contrast(1.6)' : 'none',
      '--ts-scan': lumOf(bg) > 0.55 ? 'rgba(0,0,0,.05)' : 'rgba(0,0,0,.22)',
      '--ts-on-accent': lumOf(acc) > 0.5 ? '#000' : '#fff',
    };
  }

  function applyTheme() {
    const on = cfg().skin;
    const sig = JSON.stringify([on, settings.theme, settings.custom, customImage ? customImage.length : 0, customImageAr]);
    if (sig === appliedSig) return;
    appliedSig = sig;

    COLOR_PROPS.concat(ART_PROPS).forEach(p => root.style.removeProperty(p));

    if (!on) { root.removeAttribute('data-tshell'); stopPainter(); return; }

    root.setAttribute('data-tshell', baseId());
    const p = preset(), m = p.mascot;
    if (isCustom()) setVars(customColors());
    const own = isCustom() && customImage;
    setVars({
      '--ts-mascot': `url("${own ? customImage : url('assets/' + m.f)}")`,
      '--ts-m-w': own ? NS.PRESETS.nullfiles.mascot.w : m.w,
      '--ts-m-ar': own ? (customImageAr || '1 / 1') : m.ar,
      '--ts-m-peek': own ? '30%' : m.peek,
      '--ts-m-plate': !own && m.plate ? m.plate : 'none',
      '--ts-snail': `url("${url('assets/snail.png')}")`,
    });
    const art = own ? { src: customImage, ar: customImageAr || '1 / 1' }
      : p.lockArt ? { src: url('assets/' + p.lockArt.f), ar: p.lockArt.ar } : { src: url('assets/' + m.f), ar: m.ar };
    setVars({ '--ts-art': `url("${art.src}")`, '--ts-art-ar': art.ar, '--ts-art-plate': !own && !p.lockArt && m.plate ? m.plate : 'none' });
    startPainter();
  }

  /* ---------------- background painter ----------------
     Recolours only backgrounds that are ALREADY opaque and neutral (white, grey, black).
     It never gives a transparent element a background, so overlays sitting on top of photos
     (click-catchers, lightbox layers) stay transparent and photos stay visible. */
  const P_SKIP = new Set(['SCRIPT', 'STYLE', 'IMG', 'VIDEO', 'CANVAS', 'PICTURE', 'SOURCE', 'IFRAME', 'LINK', 'META', 'NOSCRIPT', 'BR']);
  const SIDES = [['t', 'Top'], ['r', 'Right'], ['b', 'Bottom'], ['l', 'Left']];
  function borderSides(cs) {                        // which sides have a VISIBLE, neutral (grey) border
    let out = '';
    for (const [k, S] of SIDES) {
      if (!(parseFloat(cs['border' + S + 'Width']) > 0)) continue;
      const st = cs['border' + S + 'Style'];
      if (st === 'none' || st === 'hidden') continue;
      const m = (cs['border' + S + 'Color'] || '').match(/[\d.]+/g);
      if (!m) continue;
      if ((m[3] === undefined ? 1 : +m[3]) < 0.1) continue;                     // transparent sides (used for CSS triangles) stay as they are
      if (Math.max(+m[0], +m[1], +m[2]) - Math.min(+m[0], +m[1], +m[2]) >= 40) continue;   // coloured borders stay
      out += (out ? ' ' : '') + k;
    }
    return out;
  }
  let pObs = null, pWork = [], pTimer = 0;
  const pSchedule = () => { if (!pTimer) pTimer = setTimeout(pPump, 30); };
  function pEnqueue(node) {
    if (node.nodeType !== 1 || node.namespaceURI !== XHTML || P_SKIP.has(node.tagName)) return;
    pWork.push(node);
    const all = node.getElementsByTagName('*');
    for (let i = 0; i < all.length; i++) pWork.push(all[i]);
    pSchedule();
  }
  function pPump() {
    pTimer = 0;
    const reads = [];
    while (pWork.length && reads.length < 300) {
      const el = pWork.pop();
      if (el.isConnected && el.namespaceURI === XHTML && !P_SKIP.has(el.tagName) && !el.hasAttribute('data-ts-paint') && !el.hasAttribute('data-ts-solid')) reads.push(el);
    }
    const hits = [], borders = [], lines = [];
    const tv = getComputedStyle(root).getPropertyValue('--ts-bg').trim();
    const tb = /^#[0-9a-f]{3,6}$/i.test(tv) ? rgb(tv) : null;             // the theme's own background colour
    for (const el of reads) {                       // read phase (no writes, so one layout per chunk)
      if (el === document.body) continue;
      const cs = getComputedStyle(el);
      if (SITE !== 'x') { const sides = borderSides(cs); if (sides) borders.push([el, sides]); }
      const bg = cs.backgroundColor;
      if (!bg || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') continue;
      const m = bg.match(/[\d.]+/g);
      if (!m) continue;
      const r = +m[0], g = +m[1], b = +m[2], a = m[3] === undefined ? 1 : +m[3];
      if (a < 0.92) continue;                                                  // translucent: leave alone
      if (tb && Math.abs(r - tb[0]) < 3 && Math.abs(g - tb[1]) < 3 && Math.abs(b - tb[2]) < 3) continue;   // already the theme colour
      const sat = Math.max(r, g, b) - Math.min(r, g, b);
      const role = el.getAttribute('role'), h = el.offsetHeight, w = el.offsetWidth;
      if (role === 'progressbar') continue;
      if ((h < 5 || w < 5) && (h >= 20 || w >= 20)) {                          // a thin strip that is long the other way = divider line
        if (SITE !== 'x' && sat < 40) lines.push(el);
        continue;
      }
      if (role === 'separator' || h < 5 || w < 5) continue;
      hits.push([el, sat >= 26]);                                              // [element, isColoured]
    }
    for (const [el, coloured] of hits) el.setAttribute(coloured ? 'data-ts-solid' : 'data-ts-paint', '');   // write phase
    for (const [el, sides] of borders) el.setAttribute('data-ts-b', sides);
    for (const el of lines) el.setAttribute('data-ts-line', '');
    if (pWork.length) pSchedule();
  }
  function startPainter() {
    if (pObs) return;
    if (!document.body) { document.addEventListener('DOMContentLoaded', () => { if (cfg().skin) startPainter(); }, { once: true }); return; }
    pObs = new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) pEnqueue(n); });
    pObs.observe(document.body, { childList: true, subtree: true });
    pEnqueue(document.body);
  }
  function stopPainter() {
    if (pObs) { pObs.disconnect(); pObs = null; }
    pWork = []; clearTimeout(pTimer); pTimer = 0;
    document.querySelectorAll('[data-ts-paint],[data-ts-solid],[data-ts-line],[data-ts-b]').forEach(e => { ['data-ts-paint', 'data-ts-solid', 'data-ts-line', 'data-ts-b'].forEach(a => e.removeAttribute(a)); });
  }


  /* ---------------- video blocker: pause everything and lay a big red X over it ---------------- */
  const V_SEL = 'video,iframe[src*="youtube"],iframe[src*="youtu.be"],iframe[src*="vimeo"],iframe[src*="twitch"],iframe[src*="dailymotion"],iframe[src*="player"],shreddit-player,shreddit-player-2';
  const vMap = new Map();
  let vObs = null, vTimer = 0;
  const vPause = (e) => { try { e.target.pause(); } catch (_) { /* ignore */ } };
  function vCross() {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 100 100'); svg.setAttribute('preserveAspectRatio', 'none');
    [[3, 3, 97, 97], [97, 3, 3, 97]].forEach(([x1, y1, x2, y2]) => {
      const l = document.createElementNS(ns, 'line');
      l.setAttribute('x1', x1); l.setAttribute('y1', y1); l.setAttribute('x2', x2); l.setAttribute('y2', y2);
      l.setAttribute('stroke', '#e11d2a'); l.setAttribute('stroke-width', '12'); l.setAttribute('stroke-linecap', 'round');
      l.setAttribute('vector-effect', 'non-scaling-stroke');
      svg.appendChild(l);
    });
    return svg;
  }
  function vPlace(el, ov) {
    const w = el.offsetWidth, h = el.offsetHeight;
    ov.style.display = w && h ? '' : 'none';
    ov.style.left = el.offsetLeft + 'px'; ov.style.top = el.offsetTop + 'px';
    ov.style.width = w + 'px'; ov.style.height = h + 'px';
  }
  function vHandle(el) {
    if (vMap.has(el) || !el.insertAdjacentElement) return;
    const ov = document.createElement('div');
    ov.className = 'ts-vx'; ov.title = 'Videos are switched off (Null Shell)';
    ov.appendChild(vCross());
    ['click', 'mousedown', 'pointerdown', 'dblclick'].forEach(t => ov.addEventListener(t, (e) => { e.preventDefault(); e.stopPropagation(); }, true));
    el.insertAdjacentElement('afterend', ov);
    if (el.tagName === 'VIDEO') {
      el.dataset.tsm = el.muted ? '1' : '0';
      el.muted = true; el.autoplay = false;
      try { el.pause(); } catch (_) { /* ignore */ }
      el.addEventListener('play', vPause, true);
    }
    vMap.set(el, ov); vPlace(el, ov);
  }
  function vScan(node) {
    if (node.nodeType !== 1) return;
    if (node.matches && node.matches(V_SEL)) vHandle(node);
    if (node.querySelectorAll) node.querySelectorAll(V_SEL).forEach(vHandle);
  }
  function vTick() {
    for (const [el, ov] of vMap) {
      if (!el.isConnected) { ov.remove(); vMap.delete(el); continue; }
      if (!ov.isConnected) el.insertAdjacentElement('afterend', ov);
      vPlace(el, ov);
      if (el.tagName === 'VIDEO' && !el.paused) { try { el.pause(); } catch (_) { /* ignore */ } }
    }
  }
  function startVideoBlock() {
    if (vObs) return;
    if (!document.body) { document.addEventListener('DOMContentLoaded', () => { if (settings.blockVideo) startVideoBlock(); }, { once: true }); return; }
    vObs = new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) vScan(n); });
    vObs.observe(document.body, { childList: true, subtree: true });
    vScan(document.body);
    vTimer = setInterval(vTick, 700);
  }
  function stopVideoBlock() {
    if (!vObs) return;
    vObs.disconnect(); vObs = null; clearInterval(vTimer);
    for (const [el, ov] of vMap) {
      ov.remove();
      if (el.tagName === 'VIDEO') { el.removeEventListener('play', vPause, true); el.muted = el.dataset.tsm === '1'; }
    }
    vMap.clear();
  }

  /* ---------------- controls: mascot / toggle button ---------------- */
  async function toggleSkin() {
    const sites = { ...settings.sites };
    sites[SITE] = { ...sites[SITE], skin: !sites[SITE].skin };
    settings = { ...settings, sites };
    await api.storage.local.set({ settings });
    refresh();
  }
  function renderControls() {
    const on = cfg().skin, showMascot = on && settings.mascot;
    let m = document.getElementById('ts-mascot');
    if (showMascot) {
      if (!m) {
        m = document.createElement('div'); m.id = 'ts-mascot';
        m.title = 'Click to turn the Null Shell skin off on this site';
        m.addEventListener('click', toggleSkin); root.appendChild(m);
      }
    } else if (m) m.remove();
    let b = document.getElementById('ts-toggle');
    if (!showMascot) {
      if (!b) {
        b = document.createElement('button'); b.id = 'ts-toggle'; b.type = 'button'; b.textContent = '\u25D0';
        b.addEventListener('click', toggleSkin); root.appendChild(b);
      }
      b.title = on ? 'Turn the Null Shell skin off on this site' : 'Turn the Null Shell skin on for this site';
      b.classList.toggle('off', !on);
    } else if (b) b.remove();
  }

  /* ---------------- timer pill ---------------- */
  function pillLabel() {
    if (!cfg().skin) return '';
    return (isCustom() && settings.custom.pill) ? settings.custom.pill : preset().pill;
  }
  async function toggleMini() {
    settings = { ...settings, timerMini: !settings.timerMini };
    await api.storage.local.set({ settings });
    refresh();
  }
  function renderPill() {
    const r = remaining(), low = r <= 120;
    flag('data-ts-low', low);
    if (settings.timerMini) {                       // shrunk: a ring that keeps counting
      if (pill) { pill.remove(); pill = null; }
      if (!mini || !mini.isConnected) {
        mini = document.createElement('div'); mini.id = 'ts-mini';
        mini.setAttribute('role', 'button'); mini.tabIndex = 0;
        mini.appendChild(document.createElement('span'));
        mini.addEventListener('click', toggleMini);
        mini.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleMini(); } });
        root.appendChild(mini);
      }
      mini.style.setProperty('--ts-p', String(Math.max(0, Math.min(1, r / budget()))));
      mini.firstChild.textContent = r >= 60 ? Math.ceil(r / 60) + 'm' : Math.max(0, Math.round(r)) + 's';
      mini.title = 'Time left ' + fmt(r) + '. Click to show the full timer';
      mini.classList.toggle('low', low);
      return;
    }
    if (mini) { mini.remove(); mini = null; }
    if (!pill || !pill.isConnected) {
      pill = document.createElement('div'); pill.id = 'ts-pill';
      const t = document.createElement('span'); t.className = 't';
      const bar = document.createElement('div'); bar.className = 'bar';
      const fill = document.createElement('div'); fill.className = 'fill';
      bar.appendChild(fill); pill.append(t, bar);
      pill.title = 'Click to shrink the timer into a circle';
      pill.addEventListener('click', toggleMini);
      root.appendChild(pill);
    }
    pill.querySelector('.t').textContent = pillLabel() + fmt(r);
    pill.querySelector('.fill').style.width = Math.max(0, (r / budget()) * 100) + '%';
    pill.classList.toggle('low', low);
  }
  function removePill() {
    if (pill) pill.remove(); pill = null;
    if (mini) mini.remove(); mini = null;
    root.removeAttribute('data-ts-low');
  }

  /* ---------------- lock screen ---------------- */
  function showLock() {
    if (lock && lock.isConnected) return;
    document.querySelectorAll('video').forEach(v => v.pause());
    const sk = cfg().skin, L = sk ? preset().lock : NS.PLAIN_LOCK;
    const fill = (s) => s.replace('{m}', Math.round(settings.limitMin));
    lock = document.createElement('div'); lock.id = 'ts-lock';
    lock.className = sk ? 't-' + baseId() : 'plain';
    if (sk) { const f = document.createElement('div'); f.className = 'flyer'; lock.appendChild(f); }
    const copy = document.createElement('div'); copy.className = 'copy';
    const h = document.createElement('h1'); h.textContent = L.title; copy.appendChild(h);
    const p = document.createElement('p'); p.textContent = fill(L.text); copy.appendChild(p);
    if (L.tick) { const t = document.createElement('div'); t.className = 'tick'; t.textContent = L.tick; copy.appendChild(t); }
    const btn = document.createElement('button'); btn.id = 'ts-bonus'; copy.appendChild(btn);
    lock.appendChild(copy);
    root.appendChild(lock);
    root.style.overflow = 'hidden';
    if (usage.bonusUsed) { btn.textContent = L.bonus[2]; btn.disabled = true; return; }
    let wait = 30; btn.disabled = true;
    const tick = () => {
      if (wait > 0) { btn.textContent = L.bonus[0].replace('{s}', wait); wait--; }
      else { btn.textContent = L.bonus[1]; btn.disabled = false; clearInterval(lockTimer); }
    };
    tick(); lockTimer = setInterval(tick, 1000);
    btn.onclick = () => { usage.bonus += BONUS_SEC; usage.bonusUsed = true; api.storage.local.set({ usage }); hideLock(); refresh(); };
  }
  function hideLock() { clearInterval(lockTimer); if (lock) lock.remove(); lock = null; root.style.overflow = ''; }

  /* ---------------- main refresh + timing ---------------- */
  function refresh() {
    applyTheme();
    settings.blockVideo ? startVideoBlock() : stopVideoBlock();
    if (cfg().timer && remaining() <= 0) { removePill(); showLock(); }
    else { hideLock(); cfg().timer ? renderPill() : removePill(); }
    renderControls();
  }

  async function load() {
    const s = await api.storage.local.get(['settings', 'usage', 'customImage', 'customImageAr']);
    settings = NS.mergeSettings(s.settings);
    customImage = s.customImage || null; customImageAr = s.customImageAr || null;
    if (s.usage && s.usage.day === todayKey()) usage = s.usage;
    else { usage = freshUsage(); api.storage.local.set({ usage }); }
    appliedSig = null;
    refresh();
  }

  // Count only time when this tab is visible and focused.
  setInterval(async () => {
    if (!cfg().timer || document.visibilityState !== 'visible' || !document.hasFocus()) return;
    const s = await api.storage.local.get('usage');
    let u = s.usage;
    if (!u || u.day !== todayKey()) u = freshUsage();
    if (u.seconds < u.bonus + settings.limitMin * 60) u.seconds += 1;
    usage = u;
    api.storage.local.set({ usage });
    refresh();
  }, 1000);

  api.storage.onChanged.addListener((ch) => {
    if (ch.settings) settings = NS.mergeSettings(ch.settings.newValue);
    if (ch.customImage) customImage = ch.customImage.newValue || null;
    if (ch.customImageAr) customImageAr = ch.customImageAr.newValue || null;
    if (ch.usage && ch.usage.newValue) usage = ch.usage.newValue;
    refresh();
  });
  // If the page deletes the lock screen, put it back.
  new MutationObserver(() => { if (cfg().timer && remaining() <= 0 && !(lock && lock.isConnected)) showLock(); })
    .observe(root, { childList: true });

  load();
})();
