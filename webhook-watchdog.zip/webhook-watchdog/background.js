const api = chrome;
const WEBHOOK = /^https?:\/\/(?:[a-z0-9-]+\.)?discord(?:app)?\.com\/api(?:\/v\d+)?\/webhooks\/(\d+)\/([\w-]+)/i;
const DISCORD_HOST = /(^|\.)discord(app)?\.com$/;
const BAD_EXT = /\.(exe|scr|bat|cmd|vbs|ps1|msi|jar|rar|zip|7z)(\?|$)/i;
const BAD_NAME = /nitro.?gen|token.?steal|grabber|itroublve/i;
const recent = new Map();

const hostOf = u => { try { return new URL(u).hostname; } catch { return ''; } };
async function settings() {
  const { settings = {} } = await api.storage.local.get('settings');
  return { enabled: true, allow: [], ...settings };
}

async function raise(a) {
  const s = await settings();
  if (!s.enabled) return;
  const key = a.kind + a.source + a.target, now = Date.now();
  if (recent.has(key) && now - recent.get(key) < 30000) return;
  recent.set(key, now);
  const { alerts = [], unseen = 0 } = await api.storage.local.get(['alerts', 'unseen']);
  alerts.unshift({ kind: a.kind, source: a.source, target: a.target, t: now });
  alerts.length = Math.min(alerts.length, 50);
  await api.storage.local.set({ alerts, unseen: unseen + 1 });
  api.action.setBadgeText({ text: String(unseen + 1) });
  api.action.setBadgeBackgroundColor({ color: '#ff3d7f' });
  api.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: a.title, message: a.message, priority: 2, requireInteraction: true });
}

// 1) Anything in the browser posting to a Discord webhook (how stolen data is exfiltrated)
api.webRequest.onBeforeRequest.addListener(async d => {
  const m = WEBHOOK.exec(d.url);
  if (!m) return;
  const src = hostOf(d.initiator || d.originUrl || d.documentUrl || '');
  if (DISCORD_HOST.test(src)) return;
  const s = await settings();
  if (s.allow.includes(src)) return;
  raise({
    kind: 'webhook', source: src || 'unknown source', target: `webhook ${m[1]}/${m[2].slice(0, 4)}…`,
    title: 'Something is sending data to a Discord webhook',
    message: `${src || 'An unknown source'} just posted to a Discord webhook. If this is a login or "free Nitro" page, don't enter anything.`
  });
}, { urls: ['*://*.discord.com/api/*webhooks/*', '*://*.discordapp.com/api/*webhooks/*', '*://discord.com/api/*webhooks/*', '*://discordapp.com/api/*webhooks/*'] });

// 2) Executables/archives from Discord's CDN, or stealer-style filenames (TroubleGrabber's delivery route)
api.downloads.onCreated.addListener(item => {
  const url = item.finalUrl || item.url || '', host = hostOf(url);
  const name = (item.filename || url).split(/[\\/]/).pop();
  const fromDiscord = /(^|\.)(cdn\.discordapp\.com|media\.discordapp\.net)$/.test(host);
  const fromStealerRepo = /raw\.githubusercontent\.com|github\.com/.test(host) && /itroublve/i.test(url);
  if ((fromDiscord && BAD_EXT.test(url + name)) || BAD_NAME.test(name) || fromStealerRepo) {
    raise({
      kind: 'download', source: host, target: name,
      title: 'Suspicious download',
      message: `"${name}" from ${host} looks like a known credential-stealer delivery pattern. Don't run it.`
    });
  }
});
