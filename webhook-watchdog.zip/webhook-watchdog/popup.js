const $ = id => document.getElementById(id);
const LABEL = { webhook: 'Sent data to a Discord webhook', download: 'Suspicious download' };
async function load() {
  const { alerts = [], settings = {} } = await chrome.storage.local.get(['alerts', 'settings']);
  const s = { enabled: true, allow: [], ...settings };
  $('on').checked = s.enabled;
  $('state').textContent = s.enabled ? 'watching' : 'paused';
  $('allowed').textContent = s.allow.length ? 'Trusted: ' + s.allow.join(', ') : '';
  const ul = $('list'); ul.replaceChildren();
  if (!alerts.length) {
    const li = document.createElement('li'); li.className = 'empty';
    li.textContent = 'Nothing suspicious yet. Alerts appear here and as notifications.';
    ul.append(li); return;
  }
  for (const a of alerts) {
    const li = document.createElement('li'), b = document.createElement('b'), sp = document.createElement('span');
    b.textContent = LABEL[a.kind] || a.kind;
    sp.textContent = `${a.source} → ${a.target} (${new Date(a.t).toLocaleTimeString()})`;
    li.append(b, sp); ul.append(li);
  }
}
async function save(fn) {
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { enabled: true, allow: [], ...settings }; fn(s);
  await chrome.storage.local.set({ settings: s }); load();
}
$('on').onchange = e => save(s => s.enabled = e.target.checked);
$('clear').onclick = async () => { await chrome.storage.local.set({ alerts: [], unseen: 0 }); load(); };
$('add').onclick = () => {
  const h = $('host').value.trim().toLowerCase().replace(/^https?:\/\//, '').split('/')[0];
  if (h) save(s => { if (!s.allow.includes(h)) s.allow.push(h); }); $('host').value = '';
};
chrome.storage.local.set({ unseen: 0 }); chrome.action.setBadgeText({ text: '' });
load();
