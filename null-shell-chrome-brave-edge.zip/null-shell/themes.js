/* Null Shell: shared data (loaded by both the page script and the popup). */
var NS = (() => {
  const BONUS = ['Take 5 more minutes ({s}s)', 'Take 5 more minutes (once)', 'No extra time left today'];

  const PRESETS = {
    paper: {
      label: 'Light',
      pal: { bg: '#f1ebdd', fg: '#3b342b', accent: '#b5532f', acid: '#6b7a2e', blood: '#8c2f1b' },
      pill: '',
      mascot: { f: 'mouth.png', ar: '348 / 202', w: 'clamp(210px,16vw,300px)', peek: '30%' },
      lock: { title: "That's enough for today.", text: 'You used your {m} minutes. The feed will still be here tomorrow.', tick: '', bonus: BONUS },
    },
    midnight: {
      label: 'Dark',
      pal: { bg: '#12131a', fg: '#d8d6e6', accent: '#9d8cff', acid: '#7ee0c3', blood: '#5b4bd6' },
      pill: '',
      mascot: { f: 'bat.png', ar: '307 / 282', w: 'clamp(150px,11vw,220px)', peek: '26%' },
      lock: { title: 'Lights out.', text: 'You used your {m} minutes. The night is for something else.', tick: '', bonus: BONUS },
    },
    terminal: {
      label: 'Cyber',
      pal: { bg: '#0b0f0b', fg: '#9be59b', accent: '#e6f76a', acid: '#4dff6a', blood: '#1c5a1c' },
      pill: '',
      mascot: { f: 'neuromancer.png', ar: '380 / 436', w: 'clamp(170px,12vw,240px)', peek: '30%' },
      lock: { title: 'SESSION TERMINATED', text: '{m} minutes consumed. Jack out.', tick: '// NO CARRIER //',
              bonus: ['Extend session +5 min ({s}s)', 'Extend session +5 min (once)', 'NO EXTENSIONS LEFT'] },
    },
    nullfiles: {
      label: 'Subspace',
      pal: { bg: '#0d0906', fg: '#e3d9bd', accent: '#f29bb3', acid: '#c9cb3c', blood: '#a3271a' },
      pill: 'COLLAPSE T-',
      mascot: { f: 'goblin.png', ar: '420 / 489', w: 'clamp(190px,14vw,270px)', peek: '32%' },
      lockArt: { f: 'forest.jpg', ar: '742 / 960' },
      lock: { title: 'the feed can eat itself.', text: 'Your {m} minutes are gone. Let the timeline rot without you. Go make something ugly.',
              tick: 'FASTER // CLOSE THE TAB // FASTER',
              bonus: ['FEED ME 5 MORE ({s}s)', 'FEED ME 5 MORE (ONCE)', 'NOTHING LEFT. GOOD.'] },
    },
    chud: {
      label: 'Chud',
      pal: { bg: '#ffffee', fg: '#800000', accent: '#117743', acid: '#789922', blood: '#af0a0f' },
      pill: 'M\u00B4Jak Outta Sproke: ',
      mascot: { f: 'girl.gif', ar: '1 / 1', w: 'clamp(150px,11vw,210px)', peek: '22%' },
      lock: { title: 'Thread archived.', text: 'You used your {m} minutes. This thread is closed and you cannot reply anymore.',
              tick: 'M\u00B4JAK OUTTA SPROKE',
              bonus: ['Bump thread +5 min ({s}s)', 'Bump thread +5 min (once)', 'Thread is dead'] },
    },
    unc: {
      label: 'Unc',
      pal: { bg: '#dfeafa', fg: '#000033', accent: '#003399', acid: '#ff9933', blood: '#6699cc' },
      pill: 'Old Age is Coming: ',
      mascot: { f: 'rollins.png', ar: '398 / 460', w: 'clamp(170px,12vw,240px)', peek: '28%' },
      lock: { title: 'Old age is coming.', text: 'You used your {m} minutes. Call somebody. Go for a walk. Stretch.',
              tick: '~ your Top 8 have logged off ~',
              bonus: ['Five more minutes, kid ({s}s)', 'Five more minutes, kid (once)', 'Go outside'] },
    },
  };

  const ORDER = ['paper', 'midnight', 'terminal', 'nullfiles', 'chud', 'unc'];
  const PLAIN_LOCK = { title: "That's enough for today.", text: 'You used your {m} minutes. The feed will still be here tomorrow.', tick: '', bonus: BONUS };

  const SITE_HOSTS = {
    substack: /(^|\.)substack\.com$/,
    facebook: /(^|\.)facebook\.com$/,
    instagram: /(^|\.)instagram\.com$/,
    tiktok: /(^|\.)tiktok\.com$/,
  };
  const SITE_LABELS = { x: 'X / Twitter', substack: 'Substack', facebook: 'Facebook', instagram: 'Instagram', tiktok: 'TikTok' };
  // Skin is on for X and Substack; the other three run the timer only until their skin is checked on real pages.
  const SITE_DEFAULTS = {
    x: { skin: true, timer: true }, substack: { skin: true, timer: true },
    facebook: { skin: false, timer: true }, instagram: { skin: false, timer: true }, tiktok: { skin: false, timer: true },
  };

  const DEFAULTS = {
    limitMin: 20, theme: 'paper', quiet: true, nocount: true, mascot: true, hideRecs: true, hideSubs: true,
  };

  function normCustom(c) {
    c = c || {};
    const base = PRESETS[c.base] ? c.base : 'nullfiles';
    let colors = c.colors && typeof c.colors === 'object' ? { ...c.colors } : {};
    // older versions stored accent/acid/blood/bg directly on custom
    if (!c.colors) ['accent', 'acid', 'blood', 'bg'].forEach(k => { if (c[k]) colors[k] = c[k]; });
    return { name: (c.name || 'Custom'), base, colors, pill: c.pill || '' };
  }

  function mergeSettings(raw) {
    raw = raw || {};
    const s = { ...DEFAULTS, ...raw };
    if (raw.goblin === false && raw.mascot === undefined) s.mascot = false;
    if (s.theme !== 'custom' && !PRESETS[s.theme]) s.theme = 'paper';
    s.custom = normCustom(raw.custom);
    s.sites = {};
    Object.keys(SITE_DEFAULTS).forEach(k => { s.sites[k] = { ...SITE_DEFAULTS[k], ...((raw.sites || {})[k] || {}) }; });
    return s;
  }

  return { PRESETS, ORDER, PLAIN_LOCK, SITE_HOSTS, SITE_LABELS, SITE_DEFAULTS, DEFAULTS, normCustom, mergeSettings };
})();
