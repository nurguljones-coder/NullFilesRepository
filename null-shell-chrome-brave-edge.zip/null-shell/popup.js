const api = globalThis.browser || globalThis.chrome;
const $ = (id) => document.getElementById(id);
let settings = NS.mergeSettings(null);

const save = () => api.storage.local.set({ settings });
const say = (t) => { $('status').textContent = t; };
const COLOR_KEYS = ['bg', 'fg', 'accent', 'acid', 'blood'];

function label(id) { return id === 'custom' ? ((settings.custom.name || '').trim() || 'Custom') : NS.PRESETS[id].label; }
function buildSelects() {
  const th = $('theme'), base = $('cbase'); th.replaceChildren(); base.replaceChildren();
  NS.ORDER.forEach(id => {
    th.add(new Option(NS.PRESETS[id].label, id));
    base.add(new Option(NS.PRESETS[id].label, id));
  });
  th.add(new Option(label('custom'), 'custom'));
}
function buildSites() {
  const t = $('sites');
  Object.keys(NS.SITE_LABELS).forEach(k => {
    const tr = document.createElement('tr');
    const name = document.createElement('td'); name.textContent = NS.SITE_LABELS[k]; tr.appendChild(name);
    ['skin', 'timer'].forEach(kind => {
      const td = document.createElement('td'), cb = document.createElement('input');
      cb.type = 'checkbox'; cb.dataset.s = k; cb.dataset.k = kind; td.appendChild(cb); tr.appendChild(td);
    });
    t.appendChild(tr);
  });
  t.addEventListener('change', (e) => {
    const s = e.target.dataset.s; if (!s) return;
    settings.sites[s][e.target.dataset.k] = e.target.checked; save();
  });
}
function showUsage(u) {
  const today = new Date().toLocaleDateString('en-CA');
  const secs = u && u.day === today ? u.seconds : 0;
  $('used').textContent = `Used today: ${Math.floor(secs / 60)}m ${secs % 60}s`;
}
function showThumb(src) { $('thumb').style.display = src ? 'block' : 'none'; if (src) $('thumb').src = src; }

function paletteOf() { return { ...NS.PRESETS[settings.custom.base].pal, ...settings.custom.colors }; }
function fillCustom() {
  $('cname').value = settings.custom.name; $('cbase').value = settings.custom.base; $('cpill').value = settings.custom.pill;
  const p = paletteOf(); COLOR_KEYS.forEach(k => { $('c_' + k).value = p[k]; });
}
function syncUI() {
  $('theme').value = settings.theme;
  $('theme').querySelector('option[value="custom"]').textContent = label('custom');
  $('custom').style.display = settings.theme === 'custom' ? 'block' : 'none';
  $('limit').value = settings.limitMin;
  ['mascot', 'quiet', 'nocount', 'hideSubs', 'hideRecs'].forEach(k => { $(k).checked = !!settings[k]; });
  document.querySelectorAll('#sites input').forEach(i => { i.checked = !!settings.sites[i.dataset.s][i.dataset.k]; });
  fillCustom();
}

(async () => {
  buildSelects(); buildSites();
  const s = await api.storage.local.get(['settings', 'usage', 'customImage']);
  settings = NS.mergeSettings(s.settings);
  syncUI(); showThumb(s.customImage); showUsage(s.usage);
})();
api.storage.onChanged.addListener((c) => {
  if (c.usage) showUsage(c.usage.newValue);
  if (c.settings) { settings = NS.mergeSettings(c.settings.newValue); syncUI(); }   // e.g. skin toggled from the page mascot
});

$('limit').onchange = (e) => { settings.limitMin = Math.min(240, Math.max(1, +e.target.value || 20)); save(); };
$('theme').onchange = (e) => { settings.theme = e.target.value; syncUI(); save(); };
['mascot', 'quiet', 'nocount', 'hideSubs', 'hideRecs'].forEach(k => { $(k).onchange = (e) => { settings[k] = e.target.checked; save(); }; });

$('cname').oninput = (e) => { settings.custom.name = e.target.value.slice(0, 16); $('theme').querySelector('option[value="custom"]').textContent = label('custom'); save(); };
$('cbase').onchange = (e) => { settings.custom.base = e.target.value; settings.custom.colors = {}; settings.custom.pill = ''; fillCustom(); save(); say('Colors reset to the ' + NS.PRESETS[e.target.value].label + ' preset'); };
$('cpill').oninput = (e) => { settings.custom.pill = e.target.value; save(); };
COLOR_KEYS.forEach(k => { $('c_' + k).oninput = (e) => { settings.custom.colors[k] = e.target.value; save(); }; });
$('rcol').onclick = () => { settings.custom.colors = {}; fillCustom(); save(); say('Colors reset'); };
$('rimg').onclick = async () => {
  await api.storage.local.remove(['customImage', 'customImageAr']); showThumb(null); $('cimg').value = ''; say('Using the preset mascot');
};

// Clear only the outer near-white background of an opaque image (flood fill from the edges),
// so JPEGs and scans don't show up as a white box. Images that already have transparency are left alone.
function clearOuterWhite(id, w, h) {
  const d = id.data;
  for (let i = 3; i < d.length; i += 4) if (d[i] < 250) return;
  const near = (p) => d[p] > 232 && d[p + 1] > 232 && d[p + 2] > 232;
  const seen = new Uint8Array(w * h), stack = [];
  const push = (x, y) => { const k = y * w + x; if (!seen[k] && near(k * 4)) { seen[k] = 1; stack.push(k); } };
  for (let x = 0; x < w; x++) { push(x, 0); push(x, h - 1); }
  for (let y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
  while (stack.length) {
    const k = stack.pop(), x = k % w, y = (k / w) | 0;
    d[k * 4 + 3] = 0;
    if (x > 0) push(x - 1, y); if (x < w - 1) push(x + 1, y);
    if (y > 0) push(x, y - 1); if (y < h - 1) push(x, y + 1);
  }
}
$('cimg').onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const bmp = await createImageBitmap(f);
    const sc = Math.min(1, 420 / bmp.width, 520 / bmp.height);
    const w = Math.max(1, Math.round(bmp.width * sc)), h = Math.max(1, Math.round(bmp.height * sc));
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d'); ctx.drawImage(bmp, 0, 0, w, h);
    const id = ctx.getImageData(0, 0, w, h); clearOuterWhite(id, w, h); ctx.putImageData(id, 0, 0);
    const url = cv.toDataURL('image/png');
    await api.storage.local.set({ customImage: url, customImageAr: `${w} / ${h}` });
    showThumb(url); say('Image saved');
  } catch (err) { say("Couldn't read that image"); }
};
