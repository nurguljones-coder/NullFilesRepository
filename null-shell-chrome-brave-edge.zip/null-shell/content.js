/* Null Shell: page script (Chrome, Brave, Edge, Firefox) */
(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const root = document.documentElement;
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const SITE = Object.keys(NS.SITE_HOSTS).find(k => NS.SITE_HOSTS[k].test(location.hostname)) || 'x';
  root.setAttribute('data-ts-site', SITE);
  const url = (p) => api.runtime.getURL(p);

  // Fonts for the Subspace theme
  const ff = document.createElement('style');
  ff.textContent = `
    @font-face{font-family:'TS Black';src:url("${url('assets/blackletter.woff2')}") format('woff2');}
    @font-face{font-family:'TS Term';src:url("${url('assets/term.woff2')}") format('woff2');}
    @font-face{font-family:'TS Type';src:url("${url('assets/type.woff2')}") format('woff2');}`;
  root.appendChild(ff);

  const BONUS_SEC = 300;
  const todayKey = () => new Date().toLocaleDateString('en-CA');
  const freshUsage = () => ({ day: todayKey(), seconds: 0, bonus: 0, bonusUsed: false });

  let settings = NS.mergeSettings(null);
  let customImage = null, customImageAr = null;
  let usage = freshUsage();
  let pill = null, lock = null, lockTimer = null, appliedSig = null;

  const cfg = () => settings.sites[SITE];
  const isCustom = () => settings.theme === 'custom';
  const baseId = () => (isCustom() ? settings.custom.base : settings.theme);
  const preset = () => NS.PRESETS[baseId()];
  const budget = () => settings.limitMin * 60 + usage.bonus;
  const remaining = () => budget() - usage.seconds;
  const fmt = (s) => { s = Math.max(0, Math.round(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  /* ---------------- colours ---------------- */
  const rgb = (h) => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const mix = (a, b, t) => '#' + a.map((v, i) => Math.round(v * (1 - t) + b[i] * t).toString(16).padStart(2, '0')).join('');
  const lumOf = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;

  const COLOR_PROPS = ['--ts-bg', '--ts-fg', '--ts-mute', '--ts-line', '--ts-accent', '--ts-acid', '--ts-blood', '--ts-scan', '--ts-on-accent'];
  const ART_PROPS = ['--ts-mascot', '--ts-m-w', '--ts-m-ar', '--ts-m-peek', '--ts-art', '--ts-art-ar'];
  const setVars = (m) => Object.entries(m).forEach(([k, v]) => root.style.setProperty(k, v));
  const flag = (name, on) => (on ? root.setAttribute(name, '') : root.removeAttribute(name));

  function customColors() {
    const p = { ...preset().pal, ...(settings.custom.colors || {}) };
    const bg = rgb(p.bg), fg = rgb(p.fg), acc = rgb(p.accent);
    return {
      '--ts-bg': p.bg, '--ts-fg': p.fg, '--ts-mute': mix(bg, fg, 0.55), '--ts-line': mix(bg, fg, 0.16),
      '--ts-accent': p.accent, '--ts-acid': p.acid, '--ts-blood': p.blood,
      '--ts-scan': lumOf(bg) > 0.55 ? 'rgba(0,0,0,.05)' : 'rgba(0,0,0,.22)',
      '--ts-on-accent': lumOf(acc) > 0.5 ? '#000' : '#fff',
    };
  }

  function applyTheme() {
    const on = cfg().skin;
    const sig = JSON.stringify([on, settings.theme, settings.custom, customImage ? customImage.length : 0, customImageAr,
      settings.quiet, settings.nocount, settings.hideRecs, settings.hideSubs]);
    if (sig === appliedSig) return;
    appliedSig = sig;

    flag('data-ts-quiet', settings.quiet);
    flag('data-ts-nocount', settings.nocount);
    flag('data-ts-hide-recs', settings.hideRecs);
    flag('data-ts-hide-subs', settings.hideSubs);
    COLOR_PROPS.concat(ART_PROPS).forEach(p => root.style.removeProperty(p));
    settings.hideRecs || settings.hideSubs ? startHider() : stopHider();

    if (!on) { root.removeAttribute('data-tshell'); stopPainter(); return; }

    root.setAttribute('data-tshell', baseId());
    const p = preset(), m = p.mascot;
    if (isCustom()) setVars(customColors());
    const own = isCustom() && customImage;
    setVars({
      '--ts-mascot': `url("${own ? customImage : url('assets/' + m.f)}")`,
      '--ts-m-w': own ? NS.PRESETS.nullfiles.mascot.w : m.w,
      '--ts-m-ar': own ? (customImageAr || '1 / 1') : m.ar,
      '--ts-m-peek': own ? '30%' : m.peek,
    });
    const art = own ? { src: customImage, ar: customImageAr || '1 / 1' }
      : p.lockArt ? { src: url('assets/' + p.lockArt.f), ar: p.lockArt.ar } : { src: url('assets/' + m.f), ar: m.ar };
    setVars({ '--ts-art': `url("${art.src}")`, '--ts-art-ar': art.ar });
    startPainter();
  }

  /* ---------------- background painter ----------------
     Recolours only backgrounds that are ALREADY opaque and neutral (white, grey, black).
     It never gives a transparent element a background, so overlays sitting on top of photos
     (click-catchers, lightbox layers) stay transparent and photos stay visible. */
  const P_SKIP = new Set(['SCRIPT', 'STYLE', 'IMG', 'VIDEO', 'CANVAS', 'PICTURE', 'SOURCE', 'IFRAME', 'LINK', 'META', 'NOSCRIPT', 'HR', 'BR', 'INPUT', 'TEXTAREA', 'SELECT']);
  let pObs = null, pWork = [], pTimer = 0;
  const pSchedule = () => { if (!pTimer) pTimer = setTimeout(pPump, 30); };
  function pEnqueue(node) {
    if (node.nodeType !== 1 || node.namespaceURI !== XHTML || P_SKIP.has(node.tagName)) return;
    pWork.push(node);
    const all = node.getElementsByTagName('*');
    for (let i = 0; i < all.length; i++) pWork.push(all[i]);
    pSchedule();
  }
  function pPump() {
    pTimer = 0;
    const reads = [];
    while (pWork.length && reads.length < 300) {
      const el = pWork.pop();
      if (el.isConnected && el.namespaceURI === XHTML && !P_SKIP.has(el.tagName) && !el.hasAttribute('data-ts-paint')) reads.push(el);
    }
    const hits = [];
    for (const el of reads) {                       // read phase (no writes, so one layout per chunk)
      const bg = getComputedStyle(el).backgroundColor;
      if (!bg || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') continue;
      const m = bg.match(/[\d.]+/g);
      if (!m) continue;
      const r = +m[0], g = +m[1], b = +m[2], a = m[3] === undefined ? 1 : +m[3];
      if (a < 0.92 || Math.max(r, g, b) - Math.min(r, g, b) >= 26) continue;   // translucent or coloured: leave alone
      const role = el.getAttribute('role');
      if (role === 'progressbar' || role === 'separator') continue;
      if (el.offsetHeight < 5 || el.offsetWidth < 5) continue;                 // keep 1-px divider lines
      hits.push(el);
    }
    for (const el of hits) el.setAttribute('data-ts-paint', '');               // write phase
    if (pWork.length) pSchedule();
  }
  function startPainter() {
    if (pObs) return;
    if (!document.body) { document.addEventListener('DOMContentLoaded', () => { if (cfg().skin) startPainter(); }, { once: true }); return; }
    pObs = new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) pEnqueue(n); });
    pObs.observe(document.body, { childList: true, subtree: true });
    pEnqueue(document.body);
  }
  function stopPainter() {
    if (pObs) { pObs.disconnect(); pObs = null; }
    pWork = []; clearTimeout(pTimer); pTimer = 0;
    document.querySelectorAll('[data-ts-paint]').forEach(e => e.removeAttribute('data-ts-paint'));
  }

  /* ---------------- hide recommendations / subscribe prompts (best effort) ---------------- */
  const H_REC = /^(recommended|suggested for you|suggested posts|people you may know|who to follow|discover more|you might also like|you might like|more like this|trending|what.s happening)/i;
  const H_SUB = /^(subscribe( to| now)?|become a (paid )?subscriber|upgrade to paid|get premium)/i;
  const H_BOX = 'aside,section,[role="complementary"],[role="region"],[data-component-name],[data-pagelet],[role="article"]';
  const H_HEAD = 'h1,h2,h3,h4,[role="heading"]' + (SITE === 'facebook' || SITE === 'instagram' ? ',span[dir="auto"]' : '');
  let hObs = null, hQueue = [], hTimer = 0;
  function hScan(node) {
    if (node.nodeType !== 1) return;
    const list = [];
    if (node.matches && node.matches(H_HEAD)) list.push(node);
    node.querySelectorAll(H_HEAD).forEach(e => list.push(e));
    for (const e of list) {
      const t = (e.textContent || '').trim();
      if (!t || t.length > 48) continue;
      const kind = settings.hideRecs && H_REC.test(t) ? 'recs' : settings.hideSubs && H_SUB.test(t) ? 'subs' : null;
      if (!kind) continue;
      const box = e.closest(H_BOX);
      if (!box || box === document.body || box.querySelector('h1,article')) continue;   // never hide the main content
      box.setAttribute('data-ts-h', kind);
    }
    if (settings.hideSubs && SITE === 'substack') {
      node.querySelectorAll('[role="dialog"],dialog').forEach(d => {
        if (d.querySelector('input[type="email"]') && /subscribe/i.test(d.textContent || '')) d.setAttribute('data-ts-h', 'subs');
      });
    }
  }
  function hPump() { hTimer = 0; const n = hQueue.splice(0, 40); n.forEach(x => x.isConnected && hScan(x)); if (hQueue.length) hTimer = setTimeout(hPump, 30); }
  function hEnqueue(n) { if (n.nodeType === 1) { hQueue.push(n); if (!hTimer) hTimer = setTimeout(hPump, 30); } }
  function startHider() {
    stopHider();
    if (!document.body) { document.addEventListener('DOMContentLoaded', startHider, { once: true }); return; }
    hObs = new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) hEnqueue(n); });
    hObs.observe(document.body, { childList: true, subtree: true });
    hEnqueue(document.body);
  }
  function stopHider() {
    if (hObs) { hObs.disconnect(); hObs = null; }
    hQueue = []; clearTimeout(hTimer); hTimer = 0;
    document.querySelectorAll('[data-ts-h]').forEach(e => e.removeAttribute('data-ts-h'));
  }

  /* ---------------- controls: mascot / toggle button ---------------- */
  async function toggleSkin() {
    const sites = { ...settings.sites };
    sites[SITE] = { ...sites[SITE], skin: !sites[SITE].skin };
    settings = { ...settings, sites };
    await api.storage.local.set({ settings });
    refresh();
  }
  function renderControls() {
    const on = cfg().skin, showMascot = on && settings.mascot;
    let m = document.getElementById('ts-mascot');
    if (showMascot) {
      if (!m) {
        m = document.createElement('div'); m.id = 'ts-mascot';
        m.title = 'Click to turn the Null Shell skin off on this site';
        m.addEventListener('click', toggleSkin); root.appendChild(m);
      }
    } else if (m) m.remove();
    let b = document.getElementById('ts-toggle');
    if (!showMascot) {
      if (!b) {
        b = document.createElement('button'); b.id = 'ts-toggle'; b.type = 'button'; b.textContent = '\u25D0';
        b.addEventListener('click', toggleSkin); root.appendChild(b);
      }
      b.title = on ? 'Turn the Null Shell skin off on this site' : 'Turn the Null Shell skin on for this site';
      b.classList.toggle('off', !on);
    } else if (b) b.remove();
  }

  /* ---------------- timer pill ---------------- */
  function pillLabel() {
    if (!cfg().skin) return '';
    return (isCustom() && settings.custom.pill) ? settings.custom.pill : preset().pill;
  }
  function renderPill() {
    if (!pill || !pill.isConnected) {
      pill = document.createElement('div'); pill.id = 'ts-pill';
      const t = document.createElement('span'); t.className = 't';
      const bar = document.createElement('div'); bar.className = 'bar';
      const fill = document.createElement('div'); fill.className = 'fill';
      bar.appendChild(fill); pill.append(t, bar);
      root.appendChild(pill);
    }
    const r = remaining();
    pill.querySelector('.t').textContent = pillLabel() + fmt(r);
    pill.querySelector('.fill').style.width = Math.max(0, (r / budget()) * 100) + '%';
    pill.classList.toggle('low', r <= 120);
    flag('data-ts-low', r <= 120);
  }
  function removePill() { if (pill) pill.remove(); pill = null; root.removeAttribute('data-ts-low'); }

  /* ---------------- lock screen ---------------- */
  function showLock() {
    if (lock && lock.isConnected) return;
    document.querySelectorAll('video').forEach(v => v.pause());
    const sk = cfg().skin, L = sk ? preset().lock : NS.PLAIN_LOCK;
    const fill = (s) => s.replace('{m}', Math.round(settings.limitMin));
    lock = document.createElement('div'); lock.id = 'ts-lock';
    lock.className = sk ? 't-' + baseId() : 'plain';
    if (sk) { const f = document.createElement('div'); f.className = 'flyer'; lock.appendChild(f); }
    const copy = document.createElement('div'); copy.className = 'copy';
    const h = document.createElement('h1'); h.textContent = L.title; copy.appendChild(h);
    const p = document.createElement('p'); p.textContent = fill(L.text); copy.appendChild(p);
    if (L.tick) { const t = document.createElement('div'); t.className = 'tick'; t.textContent = L.tick; copy.appendChild(t); }
    const btn = document.createElement('button'); btn.id = 'ts-bonus'; copy.appendChild(btn);
    lock.appendChild(copy);
    root.appendChild(lock);
    root.style.overflow = 'hidden';
    if (usage.bonusUsed) { btn.textContent = L.bonus[2]; btn.disabled = true; return; }
    let wait = 30; btn.disabled = true;
    const tick = () => {
      if (wait > 0) { btn.textContent = L.bonus[0].replace('{s}', wait); wait--; }
      else { btn.textContent = L.bonus[1]; btn.disabled = false; clearInterval(lockTimer); }
    };
    tick(); lockTimer = setInterval(tick, 1000);
    btn.onclick = () => { usage.bonus += BONUS_SEC; usage.bonusUsed = true; api.storage.local.set({ usage }); hideLock(); refresh(); };
  }
  function hideLock() { clearInterval(lockTimer); if (lock) lock.remove(); lock = null; root.style.overflow = ''; }

  /* ---------------- main refresh + timing ---------------- */
  function refresh() {
    applyTheme();
    if (cfg().timer && remaining() <= 0) { removePill(); showLock(); }
    else { hideLock(); cfg().timer ? renderPill() : removePill(); }
    renderControls();
  }

  async function load() {
    const s = await api.storage.local.get(['settings', 'usage', 'customImage', 'customImageAr']);
    settings = NS.mergeSettings(s.settings);
    customImage = s.customImage || null; customImageAr = s.customImageAr || null;
    if (s.usage && s.usage.day === todayKey()) usage = s.usage;
    else { usage = freshUsage(); api.storage.local.set({ usage }); }
    appliedSig = null;
    refresh();
  }

  // Count only time when this tab is visible and focused.
  setInterval(async () => {
    if (!cfg().timer || document.visibilityState !== 'visible' || !document.hasFocus()) return;
    const s = await api.storage.local.get('usage');
    let u = s.usage;
    if (!u || u.day !== todayKey()) u = freshUsage();
    if (u.seconds < u.bonus + settings.limitMin * 60) u.seconds += 1;
    usage = u;
    api.storage.local.set({ usage });
    refresh();
  }, 1000);

  api.storage.onChanged.addListener((ch) => {
    if (ch.settings) settings = NS.mergeSettings(ch.settings.newValue);
    if (ch.customImage) customImage = ch.customImage.newValue || null;
    if (ch.customImageAr) customImageAr = ch.customImageAr.newValue || null;
    if (ch.usage && ch.usage.newValue) usage = ch.usage.newValue;
    refresh();
  });
  // If the page deletes the lock screen, put it back.
  new MutationObserver(() => { if (cfg().timer && remaining() <= 0 && !(lock && lock.isConnected)) showLock(); })
    .observe(root, { childList: true });

  load();
})();
