# Null Shell

A skin and a daily scroll-time limit for X, Substack, Facebook, Instagram and TikTok.
Themes: Light, Dark, Cyber, Subspace, Chud, Unc, and Custom (based on any preset).

## Chrome, Brave, Edge (and Opera, Vivaldi)
1. Unzip `null-shell-chrome-brave-edge.zip`. You get a folder called `null-shell`.
2. Open `chrome://extensions` (Brave: `brave://extensions`, Edge: `edge://extensions`).
3. Turn on Developer mode, click "Load unpacked", and pick the `null-shell` folder.
4. Pin the extension and click its icon to set your limit, theme and options.

To update: copy the new files over the old folder, then press the reload button on the extension card.
(Loading from a *different* folder makes the browser treat it as a new extension and your saved settings and today's usage start over.)

## Firefox (desktop)
Temporary: open `about:debugging#/runtime/this-firefox`, click "Load Temporary Add-on", and choose `manifest.json` from the unzipped
`null-shell-firefox` folder (or the zip). It stays until you restart Firefox.
Permanent: Firefox only installs signed add-ons. Submit the zip to addons.mozilla.org as "unlisted" (free) and install the signed file it returns.

## Firefox for Android
Firefox for Android runs the same package. It has to be signed through addons.mozilla.org (see above) and then added to
Firefox for Android through an add-on collection. Chrome for Android, iOS Safari, and Internet Explorer cannot run this extension.

## On the page
- Click the mascot to switch the skin off for that site (click the small round button that replaces it to switch it back on). The timer keeps running.
- Per-site Skin and Timer checkboxes are in the popup. Facebook, Instagram and TikTok start with the skin off.
- The popup's "Hide subscribe prompts" and "Hide recommendations" are best-effort on Substack, Facebook and Instagram, and more reliable on X.

## Custom theme
Pick "Custom": choose a base preset, then change colors, the countdown text, the name, and upload your own mascot (transparent PNGs work best;
an opaque image gets its outer white background cleared).
